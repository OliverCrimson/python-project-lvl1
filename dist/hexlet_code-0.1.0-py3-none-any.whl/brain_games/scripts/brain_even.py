from brain_games.engine import please_go_game
from brain_games.games import even_game


def main():
    please_go_game(even_game)


if __name__ == '__main__':
    main()
