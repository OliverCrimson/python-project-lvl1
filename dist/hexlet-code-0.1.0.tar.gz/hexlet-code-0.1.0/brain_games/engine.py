import prompt


NUMBER_OF_ROUNDS = 3


def please_go_game(game):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print('Hello, {x}!'.format(x=name))
    print(game.DESCRIPTION)
    for i in range(NUMBER_OF_ROUNDS):
        task, correct_answer = game.form_task_and_answer()
        print('Question:', task)
        answer = prompt.string('Your answer: ')
        if str(correct_answer) == answer:
            print('Correct!')
        else:
            print("'{x}' is wrong answer ;(."
                  " Correct answer was '{y}'.".format(x=answer, y=correct_answer))
            print("Let's try again, {x}!".format(x=name))
            return
    print("Congratulations, {x}!".format(x=name))
